﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReferenceStatistics
{
    static class ReferenceStatistics
    {
        /// <summary>
        /// A program to gather data on workflow for the Learning Commons across the six Jefferson Campuses.
        /// Written by: Jamie Pollock, JCTC Downtown Learning Commons Information Technology Specialist
        /// </summary>

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new RS_App());
        }
    }
}
