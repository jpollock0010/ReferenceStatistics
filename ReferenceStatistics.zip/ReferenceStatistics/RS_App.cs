﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReferenceStatistics
{
    public partial class RS_App : Form
    {
        public RS_App()
        {
            InitializeComponent();
        }
                
        private void RS_App_Load(object sender, EventArgs e)
        {

        }

        private void ChangeTimeChkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (!ChangeTimeChkBox.Checked)
            {
                dateTimeTimer.Enabled = true;
            }
            else
            {
                dateTimeTimer.Enabled = false;
            }
        }

        private void DateTimeTimer_Tick(object sender, EventArgs e)
        {
            TimePicker.Value = DateTime.Now;
        }

        private void DateChangeChkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (DateChangeChkBox.Checked)
            {
                DatePicker.Value = DateTime.Now;
            }
        }

        private void DatePicker_ValueChanged(object sender, EventArgs e)
        {
            if (DatePicker.Value != DateTime.Now)
            {
                DateChangeChkBox.Checked = false;
            }
        }
    }
}
