﻿namespace ReferenceStatistics
{
    partial class RS_App
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CampusLbl = new System.Windows.Forms.Label();
            this.CampusComboBox = new System.Windows.Forms.ComboBox();
            this.NameInputLbl = new System.Windows.Forms.Label();
            this.NameInputTxtBox = new System.Windows.Forms.TextBox();
            this.DateLbl = new System.Windows.Forms.Label();
            this.DatePicker = new System.Windows.Forms.DateTimePicker();
            this.TimeLbl = new System.Windows.Forms.Label();
            this.ChangeTimeChkBox = new System.Windows.Forms.CheckBox();
            this.WorkstationLbl = new System.Windows.Forms.Label();
            this.WorkstationComboBox = new System.Windows.Forms.ComboBox();
            this.Group1Panel = new System.Windows.Forms.Panel();
            this.TimePicker = new System.Windows.Forms.DateTimePicker();
            this.ContactMethodLbl = new System.Windows.Forms.Label();
            this.InPersonRadioBtn = new System.Windows.Forms.RadioButton();
            this.EmailRadioBtn = new System.Windows.Forms.RadioButton();
            this.PhoneRadioBtn = new System.Windows.Forms.RadioButton();
            this.InteractionTypeLbl = new System.Windows.Forms.Label();
            this.InteractionTypeComboBx = new System.Windows.Forms.ComboBox();
            this.ResolvedLbl = new System.Windows.Forms.Label();
            this.YesRadioBtn = new System.Windows.Forms.RadioButton();
            this.NoRadioBtn = new System.Windows.Forms.RadioButton();
            this.CommentsLbl1 = new System.Windows.Forms.Label();
            this.CommentsLbl2 = new System.Windows.Forms.Label();
            this.CommentsTxtBx = new System.Windows.Forms.TextBox();
            this.BatchInputLbl = new System.Windows.Forms.Label();
            this.BatchCounterBx = new System.Windows.Forms.NumericUpDown();
            this.SubmitBtn = new System.Windows.Forms.Button();
            this.LCRSLogo = new System.Windows.Forms.PictureBox();
            this.dateTimeTimer = new System.Windows.Forms.Timer(this.components);
            this.DateChangeChkBox = new System.Windows.Forms.CheckBox();
            this.Group1Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BatchCounterBx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LCRSLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // CampusLbl
            // 
            this.CampusLbl.AutoSize = true;
            this.CampusLbl.BackColor = System.Drawing.Color.Transparent;
            this.CampusLbl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CampusLbl.Location = new System.Drawing.Point(14, 85);
            this.CampusLbl.Name = "CampusLbl";
            this.CampusLbl.Size = new System.Drawing.Size(79, 19);
            this.CampusLbl.TabIndex = 3;
            this.CampusLbl.Text = "Campus:";
            // 
            // CampusComboBox
            // 
            this.CampusComboBox.FormattingEnabled = true;
            this.CampusComboBox.Items.AddRange(new object[] {
            " ",
            "Bullitt",
            "Carrollton",
            "Downtown",
            "Shelby",
            "Southwest",
            "Tech"});
            this.CampusComboBox.Location = new System.Drawing.Point(18, 108);
            this.CampusComboBox.Name = "CampusComboBox";
            this.CampusComboBox.Size = new System.Drawing.Size(254, 29);
            this.CampusComboBox.Sorted = true;
            this.CampusComboBox.TabIndex = 4;
            // 
            // NameInputLbl
            // 
            this.NameInputLbl.AutoSize = true;
            this.NameInputLbl.BackColor = System.Drawing.Color.Transparent;
            this.NameInputLbl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameInputLbl.Location = new System.Drawing.Point(14, 163);
            this.NameInputLbl.Name = "NameInputLbl";
            this.NameInputLbl.Size = new System.Drawing.Size(62, 19);
            this.NameInputLbl.TabIndex = 5;
            this.NameInputLbl.Text = "Name:";
            // 
            // NameInputTxtBox
            // 
            this.NameInputTxtBox.Location = new System.Drawing.Point(18, 185);
            this.NameInputTxtBox.Name = "NameInputTxtBox";
            this.NameInputTxtBox.Size = new System.Drawing.Size(254, 27);
            this.NameInputTxtBox.TabIndex = 6;
            this.NameInputTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DateLbl
            // 
            this.DateLbl.AutoSize = true;
            this.DateLbl.BackColor = System.Drawing.Color.Transparent;
            this.DateLbl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateLbl.Location = new System.Drawing.Point(14, 243);
            this.DateLbl.Name = "DateLbl";
            this.DateLbl.Size = new System.Drawing.Size(49, 19);
            this.DateLbl.TabIndex = 7;
            this.DateLbl.Text = "Date:";
            // 
            // DatePicker
            // 
            this.DatePicker.CalendarFont = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DatePicker.Checked = false;
            this.DatePicker.CustomFormat = "M/d/yyyy";
            this.DatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DatePicker.Location = new System.Drawing.Point(18, 265);
            this.DatePicker.Name = "DatePicker";
            this.DatePicker.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.DatePicker.Size = new System.Drawing.Size(128, 27);
            this.DatePicker.TabIndex = 8;
            this.DatePicker.ValueChanged += new System.EventHandler(this.DatePicker_ValueChanged);
            // 
            // TimeLbl
            // 
            this.TimeLbl.AutoSize = true;
            this.TimeLbl.BackColor = System.Drawing.Color.Transparent;
            this.TimeLbl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TimeLbl.Location = new System.Drawing.Point(168, 243);
            this.TimeLbl.Name = "TimeLbl";
            this.TimeLbl.Size = new System.Drawing.Size(50, 19);
            this.TimeLbl.TabIndex = 9;
            this.TimeLbl.Text = "Time:";
            // 
            // ChangeTimeChkBox
            // 
            this.ChangeTimeChkBox.AutoSize = true;
            this.ChangeTimeChkBox.BackColor = System.Drawing.Color.Transparent;
            this.ChangeTimeChkBox.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangeTimeChkBox.Location = new System.Drawing.Point(172, 292);
            this.ChangeTimeChkBox.Name = "ChangeTimeChkBox";
            this.ChangeTimeChkBox.Size = new System.Drawing.Size(104, 21);
            this.ChangeTimeChkBox.TabIndex = 12;
            this.ChangeTimeChkBox.Text = "Change Time";
            this.ChangeTimeChkBox.UseVisualStyleBackColor = false;
            this.ChangeTimeChkBox.CheckedChanged += new System.EventHandler(this.ChangeTimeChkBox_CheckedChanged);
            // 
            // WorkstationLbl
            // 
            this.WorkstationLbl.AutoSize = true;
            this.WorkstationLbl.BackColor = System.Drawing.Color.Transparent;
            this.WorkstationLbl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WorkstationLbl.Location = new System.Drawing.Point(14, 339);
            this.WorkstationLbl.Name = "WorkstationLbl";
            this.WorkstationLbl.Size = new System.Drawing.Size(100, 19);
            this.WorkstationLbl.TabIndex = 13;
            this.WorkstationLbl.Text = "Workstation:";
            // 
            // WorkstationComboBox
            // 
            this.WorkstationComboBox.FormattingEnabled = true;
            this.WorkstationComboBox.Items.AddRange(new object[] {
            " ",
            "Ask A Librarian",
            "Central Service Desk",
            "Classroom / Lab",
            "Computer Help Desk",
            "Office",
            "Tutoring"});
            this.WorkstationComboBox.Location = new System.Drawing.Point(18, 361);
            this.WorkstationComboBox.Name = "WorkstationComboBox";
            this.WorkstationComboBox.Size = new System.Drawing.Size(254, 29);
            this.WorkstationComboBox.TabIndex = 14;
            // 
            // Group1Panel
            // 
            this.Group1Panel.BackColor = System.Drawing.Color.Transparent;
            this.Group1Panel.BackgroundImage = global::ReferenceStatistics.Properties.Resources.BackgroundImg;
            this.Group1Panel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Group1Panel.Controls.Add(this.DateChangeChkBox);
            this.Group1Panel.Controls.Add(this.TimePicker);
            this.Group1Panel.Location = new System.Drawing.Point(-11, 55);
            this.Group1Panel.Name = "Group1Panel";
            this.Group1Panel.Size = new System.Drawing.Size(303, 365);
            this.Group1Panel.TabIndex = 15;
            // 
            // TimePicker
            // 
            this.TimePicker.Checked = false;
            this.TimePicker.CustomFormat = "h:mm tt";
            this.TimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TimePicker.Location = new System.Drawing.Point(181, 208);
            this.TimePicker.Name = "TimePicker";
            this.TimePicker.ShowUpDown = true;
            this.TimePicker.Size = new System.Drawing.Size(100, 27);
            this.TimePicker.TabIndex = 0;
            // 
            // ContactMethodLbl
            // 
            this.ContactMethodLbl.AutoSize = true;
            this.ContactMethodLbl.BackColor = System.Drawing.Color.Transparent;
            this.ContactMethodLbl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContactMethodLbl.Location = new System.Drawing.Point(318, 81);
            this.ContactMethodLbl.Name = "ContactMethodLbl";
            this.ContactMethodLbl.Size = new System.Drawing.Size(155, 19);
            this.ContactMethodLbl.TabIndex = 16;
            this.ContactMethodLbl.Text = "Method of Contact:";
            // 
            // InPersonRadioBtn
            // 
            this.InPersonRadioBtn.AutoSize = true;
            this.InPersonRadioBtn.BackColor = System.Drawing.Color.Transparent;
            this.InPersonRadioBtn.Location = new System.Drawing.Point(322, 103);
            this.InPersonRadioBtn.Name = "InPersonRadioBtn";
            this.InPersonRadioBtn.Size = new System.Drawing.Size(98, 25);
            this.InPersonRadioBtn.TabIndex = 17;
            this.InPersonRadioBtn.Text = "In-Person";
            this.InPersonRadioBtn.UseVisualStyleBackColor = false;
            // 
            // EmailRadioBtn
            // 
            this.EmailRadioBtn.AutoSize = true;
            this.EmailRadioBtn.BackColor = System.Drawing.Color.Transparent;
            this.EmailRadioBtn.Location = new System.Drawing.Point(535, 103);
            this.EmailRadioBtn.Name = "EmailRadioBtn";
            this.EmailRadioBtn.Size = new System.Drawing.Size(69, 25);
            this.EmailRadioBtn.TabIndex = 18;
            this.EmailRadioBtn.TabStop = true;
            this.EmailRadioBtn.Text = "Email";
            this.EmailRadioBtn.UseVisualStyleBackColor = false;
            // 
            // PhoneRadioBtn
            // 
            this.PhoneRadioBtn.AutoSize = true;
            this.PhoneRadioBtn.BackColor = System.Drawing.Color.Transparent;
            this.PhoneRadioBtn.Location = new System.Drawing.Point(717, 103);
            this.PhoneRadioBtn.Name = "PhoneRadioBtn";
            this.PhoneRadioBtn.Size = new System.Drawing.Size(77, 25);
            this.PhoneRadioBtn.TabIndex = 19;
            this.PhoneRadioBtn.TabStop = true;
            this.PhoneRadioBtn.Text = "Phone";
            this.PhoneRadioBtn.UseVisualStyleBackColor = false;
            // 
            // InteractionTypeLbl
            // 
            this.InteractionTypeLbl.AutoSize = true;
            this.InteractionTypeLbl.BackColor = System.Drawing.Color.Transparent;
            this.InteractionTypeLbl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InteractionTypeLbl.Location = new System.Drawing.Point(318, 154);
            this.InteractionTypeLbl.Name = "InteractionTypeLbl";
            this.InteractionTypeLbl.Size = new System.Drawing.Size(154, 19);
            this.InteractionTypeLbl.TabIndex = 20;
            this.InteractionTypeLbl.Text = "Type of Interaction:";
            // 
            // InteractionTypeComboBx
            // 
            this.InteractionTypeComboBx.FormattingEnabled = true;
            this.InteractionTypeComboBx.Items.AddRange(new object[] {
            " ",
            "Basic Resources",
            "Computer Help",
            "Copier Assistance",
            "Directional",
            "Email Assistance",
            "Faculty / Staff Assistance",
            "Password Reset",
            "Policy Enforcement",
            "Printing Assistance",
            "Scanner Assistance",
            "Student Services"});
            this.InteractionTypeComboBx.Location = new System.Drawing.Point(322, 176);
            this.InteractionTypeComboBx.Name = "InteractionTypeComboBx";
            this.InteractionTypeComboBx.Size = new System.Drawing.Size(260, 29);
            this.InteractionTypeComboBx.TabIndex = 21;
            // 
            // ResolvedLbl
            // 
            this.ResolvedLbl.AutoSize = true;
            this.ResolvedLbl.BackColor = System.Drawing.Color.Transparent;
            this.ResolvedLbl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResolvedLbl.Location = new System.Drawing.Point(665, 154);
            this.ResolvedLbl.Name = "ResolvedLbl";
            this.ResolvedLbl.Size = new System.Drawing.Size(82, 19);
            this.ResolvedLbl.TabIndex = 22;
            this.ResolvedLbl.Text = "Resolved:";
            // 
            // YesRadioBtn
            // 
            this.YesRadioBtn.AutoSize = true;
            this.YesRadioBtn.BackColor = System.Drawing.Color.Transparent;
            this.YesRadioBtn.Location = new System.Drawing.Point(669, 177);
            this.YesRadioBtn.Name = "YesRadioBtn";
            this.YesRadioBtn.Size = new System.Drawing.Size(55, 25);
            this.YesRadioBtn.TabIndex = 23;
            this.YesRadioBtn.Text = "Yes";
            this.YesRadioBtn.UseVisualStyleBackColor = false;
            // 
            // NoRadioBtn
            // 
            this.NoRadioBtn.AutoSize = true;
            this.NoRadioBtn.BackColor = System.Drawing.Color.Transparent;
            this.NoRadioBtn.Location = new System.Drawing.Point(744, 177);
            this.NoRadioBtn.Name = "NoRadioBtn";
            this.NoRadioBtn.Size = new System.Drawing.Size(50, 25);
            this.NoRadioBtn.TabIndex = 24;
            this.NoRadioBtn.TabStop = true;
            this.NoRadioBtn.Text = "No";
            this.NoRadioBtn.UseVisualStyleBackColor = false;
            // 
            // CommentsLbl1
            // 
            this.CommentsLbl1.AutoSize = true;
            this.CommentsLbl1.BackColor = System.Drawing.Color.Transparent;
            this.CommentsLbl1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CommentsLbl1.Location = new System.Drawing.Point(318, 223);
            this.CommentsLbl1.Name = "CommentsLbl1";
            this.CommentsLbl1.Size = new System.Drawing.Size(97, 19);
            this.CommentsLbl1.TabIndex = 25;
            this.CommentsLbl1.Text = "Comments:";
            // 
            // CommentsLbl2
            // 
            this.CommentsLbl2.AutoSize = true;
            this.CommentsLbl2.BackColor = System.Drawing.Color.Transparent;
            this.CommentsLbl2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CommentsLbl2.Location = new System.Drawing.Point(319, 242);
            this.CommentsLbl2.Name = "CommentsLbl2";
            this.CommentsLbl2.Size = new System.Drawing.Size(304, 17);
            this.CommentsLbl2.TabIndex = 26;
            this.CommentsLbl2.Text = "e.g. further action needed, if/why unresolved, etc.";
            // 
            // CommentsTxtBx
            // 
            this.CommentsTxtBx.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CommentsTxtBx.Location = new System.Drawing.Point(322, 263);
            this.CommentsTxtBx.Multiline = true;
            this.CommentsTxtBx.Name = "CommentsTxtBx";
            this.CommentsTxtBx.Size = new System.Drawing.Size(477, 86);
            this.CommentsTxtBx.TabIndex = 27;
            // 
            // BatchInputLbl
            // 
            this.BatchInputLbl.AutoSize = true;
            this.BatchInputLbl.BackColor = System.Drawing.Color.Transparent;
            this.BatchInputLbl.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BatchInputLbl.Location = new System.Drawing.Point(318, 369);
            this.BatchInputLbl.Name = "BatchInputLbl";
            this.BatchInputLbl.Size = new System.Drawing.Size(100, 19);
            this.BatchInputLbl.TabIndex = 28;
            this.BatchInputLbl.Text = "Batch Input:";
            // 
            // BatchCounterBx
            // 
            this.BatchCounterBx.Location = new System.Drawing.Point(420, 366);
            this.BatchCounterBx.Name = "BatchCounterBx";
            this.BatchCounterBx.Size = new System.Drawing.Size(47, 27);
            this.BatchCounterBx.TabIndex = 29;
            this.BatchCounterBx.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // SubmitBtn
            // 
            this.SubmitBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitBtn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.SubmitBtn.Location = new System.Drawing.Point(683, 365);
            this.SubmitBtn.Name = "SubmitBtn";
            this.SubmitBtn.Size = new System.Drawing.Size(116, 28);
            this.SubmitBtn.TabIndex = 30;
            this.SubmitBtn.Text = "Submit";
            this.SubmitBtn.UseVisualStyleBackColor = true;
            // 
            // LCRSLogo
            // 
            this.LCRSLogo.BackColor = System.Drawing.Color.Transparent;
            this.LCRSLogo.Image = global::ReferenceStatistics.Properties.Resources.Learning_Commons_Lib_Guides_Header_RS;
            this.LCRSLogo.Location = new System.Drawing.Point(-3, -1);
            this.LCRSLogo.Name = "LCRSLogo";
            this.LCRSLogo.Size = new System.Drawing.Size(830, 60);
            this.LCRSLogo.TabIndex = 2;
            this.LCRSLogo.TabStop = false;
            // 
            // dateTimeTimer
            // 
            this.dateTimeTimer.Enabled = true;
            this.dateTimeTimer.Interval = 1000;
            this.dateTimeTimer.Tick += new System.EventHandler(this.DateTimeTimer_Tick);
            // 
            // DateChangeChkBox
            // 
            this.DateChangeChkBox.AutoSize = true;
            this.DateChangeChkBox.Checked = true;
            this.DateChangeChkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.DateChangeChkBox.Font = new System.Drawing.Font("Century Gothic", 9F);
            this.DateChangeChkBox.Location = new System.Drawing.Point(27, 235);
            this.DateChangeChkBox.Name = "DateChangeChkBox";
            this.DateChangeChkBox.Size = new System.Drawing.Size(104, 21);
            this.DateChangeChkBox.TabIndex = 1;
            this.DateChangeChkBox.Text = "Current Date";
            this.DateChangeChkBox.UseVisualStyleBackColor = true;
            this.DateChangeChkBox.CheckedChanged += new System.EventHandler(this.DateChangeChkBox_CheckedChanged);
            // 
            // RS_App
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(180)))), ((int)(((byte)(230)))));
            this.BackgroundImage = global::ReferenceStatistics.Properties.Resources.BackgroundImg;
            this.ClientSize = new System.Drawing.Size(820, 411);
            this.Controls.Add(this.SubmitBtn);
            this.Controls.Add(this.BatchCounterBx);
            this.Controls.Add(this.BatchInputLbl);
            this.Controls.Add(this.CommentsTxtBx);
            this.Controls.Add(this.CommentsLbl2);
            this.Controls.Add(this.CommentsLbl1);
            this.Controls.Add(this.NoRadioBtn);
            this.Controls.Add(this.YesRadioBtn);
            this.Controls.Add(this.ResolvedLbl);
            this.Controls.Add(this.InteractionTypeComboBx);
            this.Controls.Add(this.InteractionTypeLbl);
            this.Controls.Add(this.PhoneRadioBtn);
            this.Controls.Add(this.EmailRadioBtn);
            this.Controls.Add(this.InPersonRadioBtn);
            this.Controls.Add(this.ContactMethodLbl);
            this.Controls.Add(this.WorkstationComboBox);
            this.Controls.Add(this.WorkstationLbl);
            this.Controls.Add(this.ChangeTimeChkBox);
            this.Controls.Add(this.TimeLbl);
            this.Controls.Add(this.DatePicker);
            this.Controls.Add(this.DateLbl);
            this.Controls.Add(this.NameInputTxtBox);
            this.Controls.Add(this.NameInputLbl);
            this.Controls.Add(this.CampusComboBox);
            this.Controls.Add(this.CampusLbl);
            this.Controls.Add(this.LCRSLogo);
            this.Controls.Add(this.Group1Panel);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Location = new System.Drawing.Point(30, 30);
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.Name = "RS_App";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reference Statistics";
            this.Load += new System.EventHandler(this.RS_App_Load);
            this.Group1Panel.ResumeLayout(false);
            this.Group1Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BatchCounterBx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LCRSLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox LCRSLogo;
        private System.Windows.Forms.Label CampusLbl;
        private System.Windows.Forms.ComboBox CampusComboBox;
        private System.Windows.Forms.Label NameInputLbl;
        private System.Windows.Forms.TextBox NameInputTxtBox;
        private System.Windows.Forms.Label DateLbl;
        private System.Windows.Forms.DateTimePicker DatePicker;
        private System.Windows.Forms.Label TimeLbl;
        private System.Windows.Forms.CheckBox ChangeTimeChkBox;
        private System.Windows.Forms.Label WorkstationLbl;
        private System.Windows.Forms.ComboBox WorkstationComboBox;
        private System.Windows.Forms.Panel Group1Panel;
        private System.Windows.Forms.Label ContactMethodLbl;
        private System.Windows.Forms.RadioButton InPersonRadioBtn;
        private System.Windows.Forms.RadioButton EmailRadioBtn;
        private System.Windows.Forms.RadioButton PhoneRadioBtn;
        private System.Windows.Forms.Label InteractionTypeLbl;
        private System.Windows.Forms.ComboBox InteractionTypeComboBx;
        private System.Windows.Forms.Label ResolvedLbl;
        private System.Windows.Forms.RadioButton YesRadioBtn;
        private System.Windows.Forms.RadioButton NoRadioBtn;
        private System.Windows.Forms.Label CommentsLbl1;
        private System.Windows.Forms.Label CommentsLbl2;
        private System.Windows.Forms.TextBox CommentsTxtBx;
        private System.Windows.Forms.Label BatchInputLbl;
        private System.Windows.Forms.NumericUpDown BatchCounterBx;
        private System.Windows.Forms.Button SubmitBtn;
        private System.Windows.Forms.DateTimePicker TimePicker;
        private System.Windows.Forms.Timer dateTimeTimer;
        private System.Windows.Forms.CheckBox DateChangeChkBox;
    }
}

